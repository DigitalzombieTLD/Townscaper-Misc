Layered and Commented TownColor.png GIMP file to make your own texture edits
made by Sem ( https://sem-from-france.carrd.co/ )